nomecompleto = "roger437unix AWS BeanStalk"
# Informe seu nome completo acima

config = {  
  'username': nomecompleto
}
