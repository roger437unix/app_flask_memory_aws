![](https://static.javatpoint.com/tutorial/flask/images/flask-tutorial.png)


# Agenda Flask Python em Memória para uso em AWS Elastic Beanstalk

zip -vr application.zip ./


